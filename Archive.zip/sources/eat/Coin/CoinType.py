from enum import Enum

class CoinType(Enum):
    BRONZE = 10
    SILVER = 20
    GOLD = 30