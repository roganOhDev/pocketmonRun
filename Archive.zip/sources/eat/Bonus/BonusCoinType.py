from enum import Enum


class BonusCoinType(Enum):
    B = 1
    O = 2
    N = 3
    U = 4
    S = 5
    FULL = 0
