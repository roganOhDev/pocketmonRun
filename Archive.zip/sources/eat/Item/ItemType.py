from enum import Enum


class ItemType(Enum):
    GIANT = 1
    BOOST = 2
    REVIVE = 3
    HEALTH = 4
