from enum import Enum

class SkillType(Enum):
    TIME = 1
    PASSIVE = 2